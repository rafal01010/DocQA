# dots.ocr

- Maintainer: rednote hilab (Xiaohongshu)
- License: MIT
- Pipeline tag: `image-text-to-text`
- Library: `dots_ocr` (custom code)
- Language coverage: English, Chinese, multilingual
- Model size: 1.7B vision-language model with prompt-driven task switching

## Highlights
- Unified model for multilingual layout detection and OCR with reading-order preservation in a single VLM.
- SOTA on OmniDocBench for text, tables, and reading order; competitive formulas versus larger models (Doubao-1.5, Gemini 2.5 Pro).
- Robust on low-resource languages and supports layout-only, OCR-only, and grounding prompts via prompt templates.
- Live demo, blog, and community links provided in the upstream repository.

## Installation
```bash
conda create -n dots_ocr python=3.12
conda activate dots_ocr

git clone https://github.com/rednote-hilab/dots.ocr.git
cd dots.ocr

# Install PyTorch built for your CUDA version
pip install torch==2.7.0 torchvision==0.22.0 torchaudio==2.7.0 --index-url https://download.pytorch.org/whl/cu128
pip install -e .
```
- Docker image `rednotehilab/dots.ocr` contains the ready-to-run environment; run `pip install -e .` inside the container if needed.

## Download model weights
```bash
python3 tools/download_model.py
```
- Save directories must avoid periods (e.g., `DotsOCR`) to work with the current tooling.

## Deployment
- All reported evaluations use `vllm` 0.9.1; the project ships a Dockerfile to rebuild the same environment.
- After downloading weights:
```bash
export hf_model_path=./weights/DotsOCR
export PYTHONPATH=$(dirname "$hf_model_path"):$PYTHONPATH
sed -i '/^from vllm\.entrypoints\.cli\.main import main$/a\
from DotsOCR import modeling_dots_ocr_vllm' `which vllm`
```
- Start the vLLM server and route requests through it; demos are available via `python demo/demo_gradio.py` and `python demo/demo_gradio_annotion.py`.

## Transformers usage
```python
import torch
from transformers import AutoModelForCausalLM, AutoProcessor
from qwen_vl_utils import process_vision_info
from dots_ocr.utils import dict_promptmode_to_prompt

model_path = "./weights/DotsOCR"
model = AutoModelForCausalLM.from_pretrained(
    model_path,
    attn_implementation="flash_attention_2",
    torch_dtype=torch.bfloat16,
    device_map="auto",
    trust_remote_code=True,
)
processor = AutoProcessor.from_pretrained(model_path, trust_remote_code=True)
```
- Build a JSON-style prompt describing bbox, category, and formatting rules, feed it with the image via `process_vision_info`, and call `model.generate(..., max_new_tokens=24000)`.
- Outputs are sorted by human reading order; prompts can be switched for layout-only, OCR-only, or grounding tasks.

## Benchmarks
- OmniDocBench: SOTA across text, table, and reading-order metrics; multilingual benchmark (EN, ZH, internal dots.ocr-bench) highlights strong performance on low-resource languages.
- Internal evaluations compare favorably to MonkeyOCR and olmOCR pipelines while keeping a compact 1.7B backbone.

## Limitations
- Complex tables/formulas and picture parsing remain challenging.
- Parsing may fail on extremely dense text or repeated special characters (`...`, `_`); try higher DPI (200) or alternative prompts (`prompt_layout_only_en`, `prompt_ocr`, `prompt_grounding_ocr`).
- Throughput is not yet optimized for very large PDF batches.

## Resources
- Model card: https://huggingface.co/rednote-hilab/dots.ocr
- Live demo: https://dotsocr.xiaohongshu.com
- Blog, prompts, and contact links are available in the GitHub repository.
