# DeepSeek-OCR

- Maintainer: DeepSeek AI
- License: MIT
- Pipeline tag: `image-text-to-text`
- Language coverage: Multilingual
- Variants: Tiny (512), Small (640), Base (1024), Large (1280), Gundam (context-compression crop mode)

## Highlights
- Vision-language OCR model focused on "contexts optical compression" for accurate document-to-markdown conversion and structured outputs.
- Ships with an `infer` helper that accepts prompts (e.g. `<|grounding|>Convert the document to markdown.`), adaptive crop modes, and optional compression for long documents.
- Supports multiple resolution presets plus Gundam mode for page tiling and compression-aware inference.
- Official vLLM integration (nightly builds) enables batched GPU inference with custom logit processors to control repetition.
- Paper and GitHub repository detail PDF workflows, compression strategy, and benchmarking against OmniDocBench and other datasets.

## Requirements
Tested with Python 3.12.9 + CUDA 11.8:
```bash
pip install torch==2.6.0 transformers==4.46.3 tokenizers==0.20.3 einops addict easydict
pip install flash-attn==2.7.3 --no-build-isolation
```

## Basic inference
```python
from transformers import AutoModel, AutoTokenizer
import torch

model_name = "deepseek-ai/DeepSeek-OCR"
tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
model = AutoModel.from_pretrained(
    model_name,
    _attn_implementation="flash_attention_2",
    trust_remote_code=True,
    use_safetensors=True,
).eval().cuda().to(torch.bfloat16)

prompt = "<image>\n<|grounding|>Convert the document to markdown. "
image_file = "your_image.jpg"
output_path = "your/output/dir"

# Choose resolution preset
res = model.infer(
    tokenizer,
    prompt=prompt,
    image_file=image_file,
    output_path=output_path,
    base_size=1024,
    image_size=640,
    crop_mode=True,
    save_results=True,
    test_compress=True,
)
print(res)
```
- Set `base_size`/`image_size` according to the desired variant (Tiny 512/512, Small 640/640, Base 1024/1024, Large 1280/1280).
- `crop_mode=True` activates Gundam-style tiling; disable for single-pass inference.
- `test_compress=True` performs context compression before decoding; disable for standard OCR.

## vLLM acceleration
```bash
uv venv
source .venv/bin/activate
uv pip install -U vllm --pre --extra-index-url https://wheels.vllm.ai/nightly
```
```python
from vllm import LLM, SamplingParams
from vllm.model_executor.models.deepseek_ocr import NGramPerReqLogitsProcessor
from PIL import Image

llm = LLM(
    model="deepseek-ai/DeepSeek-OCR",
    enable_prefix_caching=False,
    mm_processor_cache_gb=0,
    logits_processors=[NGramPerReqLogitsProcessor],
)

images = [Image.open("doc1.png").convert("RGB"), Image.open("doc2.png").convert("RGB")]
prompt = "<image>\nFree OCR."
inputs = [{"prompt": prompt, "multi_modal_data": {"image": img}} for img in images]
params = SamplingParams(
    temperature=0.0,
    max_tokens=8192,
    extra_args=dict(ngram_size=30, window_size=90, whitelist_token_ids={128821, 128822}),
    skip_special_tokens=False,
)
outputs = llm.generate(inputs, params)
for out in outputs:
    print(out.outputs[0].text)
```
- Logit processor keeps table tokens (`<td>`, `</td>`) while suppressing repetition.
- Refer to the GitHub repo for PDF ingestion, batch rendering, and compression utilities.

## Resources
- GitHub: https://github.com/deepseek-ai/DeepSeek-OCR
- Paper (PDF): https://github.com/deepseek-ai/DeepSeek-OCR/blob/main/DeepSeek_OCR_paper.pdf
- ArXiv: https://arxiv.org/abs/2510.18234
- Hugging Face model card: https://huggingface.co/deepseek-ai/DeepSeek-OCR
- Community: Discord https://discord.gg/Tc7c45Zzu5 | Twitter https://twitter.com/deepseek_ai
