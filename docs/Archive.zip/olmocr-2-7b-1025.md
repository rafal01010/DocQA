# olmOCR-2-7B-1025

- Maintainer: Allen Institute for AI (AI2)
- License: Apache-2.0
- Base model: `Qwen/Qwen2.5-VL-7B-Instruct`
- Format: Full BF16 release; FP8 checkpoint (`olmOCR-2-7B-1025-FP8`) is recommended for production inference
- Toolkit: Designed to be used with the `olmocr` package (v0.4.0+)

## Highlights
- Fine-tuned on the supervised `olmOCR-mix-1025` dataset and further improved with GRPO RL on `olmOCR-synthmix-1025` to boost math, tables, and other difficult OCR cases.
- Toolkit handles PDF rendering, rotation correction, retry logic, and batching (images should be rendered with the longest edge at 1288 px).
- Releases include paper, supervised and RL datasets, GitHub repo, and an interactive demo.

## Benchmarks (olmOCR toolkit v0.4.0)
- Overall score on olmOCR-bench: **82.3 ± 1.1**.
- Category scores: ArXiv 82.9, Old Scans Math 82.1, Tables 84.3, Old Scans 48.3, Headers & Footers 95.7, Multi-column 84.3, Long tiny text 81.4, Base 99.7.
- FP8 variant scores 82.4 ± 1.1 overall with similar per-category results.

## Usage
- Preferred path is the official toolkit: https://github.com/allenai/olmocr (includes vLLM-based pipeline for large-scale processing).
- Manual workflow requires rendering the PDF page, building the YAML prompt, and feeding an image + metadata to the model.

```bash
pip install olmocr>=0.4.0
```
```python
import torch
import base64
from io import BytesIO
from PIL import Image
from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration
from olmocr.data.renderpdf import render_pdf_to_base64png
from olmocr.prompts import build_no_anchoring_v4_yaml_prompt

model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
    "allenai/olmOCR-2-7B-1025", torch_dtype=torch.bfloat16
).eval()
processor = AutoProcessor.from_pretrained("Qwen/Qwen2.5-VL-7B-Instruct")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

image_base64 = render_pdf_to_base64png("./paper.pdf", 1, target_longest_image_dim=1288)
messages = [{
    "role": "user",
    "content": [
        {"type": "text", "text": build_no_anchoring_v4_yaml_prompt()},
        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}},
    ],
}]

text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
main_image = Image.open(BytesIO(base64.b64decode(image_base64)))
inputs = processor(text=[text], images=[main_image], padding=True, return_tensors="pt")
inputs = {k: v.to(device) for k, v in inputs.items()}

output = model.generate(**inputs, temperature=0.1, max_new_tokens=50, do_sample=True)
prompt_len = inputs["input_ids"].shape[1]
print(processor.tokenizer.batch_decode(output[:, prompt_len:], skip_special_tokens=True))
```
- Toolkit automates the rendering, metadata extraction, retries, and final Markdown/JSON output.

## Resources
- Paper: https://olmocr.allenai.org/papers/olmocr.pdf
- SFT dataset: https://huggingface.co/datasets/allenai/olmOCR-mix-1025
- RL dataset: https://huggingface.co/datasets/allenai/olmOCR-synthmix-1025
- Code & toolkit: https://github.com/allenai/olmocr
- Demo: https://olmocr.allenai.org/
- Responsible use guidelines: https://allenai.org/responsible-use
