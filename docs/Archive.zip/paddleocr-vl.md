# PaddleOCR-VL

- Maintainer: PaddlePaddle
- License: Apache-2.0
- Pipeline tag: `image-text-to-text`
- Base model: `baidu/ERNIE-4.5-0.3B-Paddle`
- Language coverage: English, Chinese, multilingual

## Highlights
- 0.9B ultra-compact vision-language model for page-level document parsing (OCR, layout, tables, formulas, charts).
- SOTA on OmniDocBench v1.5/v1.0 overall, text, formula, table, and reading-order metrics; strong in-house evaluations across text/table/formula/chart categories.
- Ships with the PaddleOCR doc parser pipeline, exposing CLI and Python APIs that output structured JSON/Markdown.
- Supports GPU-accelerated inference via the `paddlex-genai-vllm` server; limited `transformers` integration for element-level recognition tasks.

## Installation
```bash
python -m pip install paddlepaddle-gpu==3.2.0 -i https://www.paddlepaddle.org.cn/packages/stable/cu126/
python -m pip install -U "paddleocr[doc-parser]"
python -m pip install https://paddle-whl.bj.bcebos.com/nightly/cu126/safetensors/safetensors-0.6.2.dev0-cp38-abi3-linux_x86_64.whl
```
- Windows users should rely on WSL or Docker per upstream guidance.

## Basic usage
```bash
paddleocr doc_parser -i https://paddle-model-ecology.bj.bcebos.com/paddlex/imgs/demo_image/paddleocr_vl_demo.png
```

```python
from paddleocr import PaddleOCRVL

pipeline = PaddleOCRVL()
result = pipeline.predict("https://paddle-model-ecology.bj.bcebos.com/paddlex/imgs/demo_image/paddleocr_vl_demo.png")
for item in result:
    item.print()
    item.save_to_json(save_path="output")
    item.save_to_markdown(save_path="output")
```

## Accelerated inference
1. Launch the optimized VLLM server (default port 8080):
```bash
docker run --rm --gpus all --network host \
  ccr-2vdh3abv-pub.cnc.bj.baidubce.com/paddlepaddle/paddlex-genai-vllm-server
```
2. Call the CLI or Python API with the server endpoint:
```bash
paddleocr doc_parser \
  -i https://paddle-model-ecology.bj.bcebos.com/paddlex/imgs/demo_image/paddleocr_vl_demo.png \
  --vl_rec_backend vllm-server \
  --vl_rec_server_url http://127.0.0.1:8080/v1
```
```python
from paddleocr import PaddleOCRVL

pipeline = PaddleOCRVL(vl_rec_backend="vllm-server", vl_rec_server_url="http://127.0.0.1:8080/v1")
_ = pipeline.predict("https://paddle-model-ecology.bj.bcebos.com/paddlex/imgs/demo_image/paddleocr_vl_demo.png")
```

## Transformers option (element-level)
- Load `AutoModelForCausalLM` and `AutoProcessor` with `trust_remote_code=True`.
- Choose prompts for `ocr`, `table`, `chart`, or `formula` and call `.generate(max_new_tokens=1024)`.
- Upstream recommends the PaddleOCR pipeline for page-level parsing because it is faster and returns structured layouts.

## Resources
- Documentation: https://www.paddleocr.ai/latest/en/version3.x/pipeline_usage/PaddleOCR-VL.html
- Benchmarks and visualizations are available on the Hugging Face model card.
